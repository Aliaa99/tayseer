
<div class="question-form">
   <form action="" class="pt-5">
       <div class="form-control">
          <input type="text" placeholder="الاسم" class="radius px-2 py-2 mb-2">
       </div>
       <div class="form-control">
          <input type="email" placeholder="الإيميل" class="radius px-2 py-2 mb-2">
       </div>
       <div class="form-control">
            <select name="" id="" class="radius px-2 py-2 mb-2">
                <option selected disabled>نوع الاستشاره</option>
                <option >1</option>
                <option >2</option>
                <option >3</option>
            </select>
       </div>
       <div class="form-control">
          <textarea name="" id=""  rows="8" placeholder="استشارتك" class="radius px-2 py-2 mb-2"></textarea>
       </div>
       <div class="form-control center">
         <button class="background-link hvr-float-shadow"> ارسال الان </button>
       </div>

   </form>
</div>