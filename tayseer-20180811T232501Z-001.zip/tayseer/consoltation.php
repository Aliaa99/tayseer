<?php
include 'header.php';
?>

<div class="header-main py-5 text-right">
    <div class="container">
        <h2  class="mb-3">الاستشارات</h2>
        <a href="index.php">الرئيسية</a>
    </div>
</div> 

<div class="consoltation py-5 center">
  <div class="container">
        <h4 class="mb-5 center"><span class="head">أرسل استشارتك الان</span></h4>
        <p>محاسبون قانونيون ، مراقبى حسابات ، مراجعى حسابات ، مستشارون ماليون واداريون ، خبراء الضرائب </p>
  </div>
</div>




<?php
include 'share-form.php';
?>



<?php
include 'footer.php';
?>
