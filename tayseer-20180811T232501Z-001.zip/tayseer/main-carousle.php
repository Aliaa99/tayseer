<div class="main-carousle-details">
    <div class="on-img">
        <div class="container">
            <div class="caption">
                <h2  class="mb-5">شركة احمد تيسير وشركاه</h2>
                <span>محامون ومراجعون قانونين ( سجل مهنى رقم 640 )</span>
                <div class="mt-5 ">
                   <a href="#" class="transparent-link ml-3 hvr-float-shadow mb-3  movedown">من نحن</a>
                   <a href="services.php" class="background-link hvr-float-shadow mb-3">الخدمات</a>
                </div>
            </div>
        </div>
    </div>
    <div class="main-carousle owl-carousel owl-theme">
        <div class="item">
           <img src="images/slider.png" alt="">
        </div>
        <div class="item">
           <img src="images/slider.png" alt="">
        </div>
    </div>
</div>