<footer>
    <div class="footer-upper pt-5">
        <div class="container">
            <div class="images-logo2 center mb-5">
                <img src="images/logo2.png" alt="">
            </div>
            <div class="row">
                <div class="col-md-6 text-right">
                    <h5 class="pt-5">من نحن</h5>
                    <p class="pt-3 para">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالهنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالهنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالهنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالهنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالهنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالهنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغال</p>
                    <div class="social my-4">
                        <a href="#" class="hvr-bounce-in"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="hvr-bounce-in"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="hvr-bounce-in"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="hvr-bounce-in"><i class="fab fa-google-plus-g"></i></a>
                    </div>
                </div>
                <div class="col-md-3 text-right">
                    <h5 class="pt-5">روابط مهمه</h5>
                    <ul class="pages pt-3">
                        <li class="mb-3"><a href="#">الرئيسية</a></li>
                        <li class="mb-3"><a href="#">من نحن</a></li>
                        <li class="mb-3"><a href="#">الاستثمارات</a></li>
                        <li class="mb-3"><a href="#">خدمات محاسبية</a></li>
                        <li class="mb-3"><a href="#">الرؤية</a></li>
                    </ul>
                </div>
                <div class="col-md-3 text-right">
                    <h5 class="pt-5">تواصل معنا </h5>
                    <ul class="pt-3">
                        <li class="mb-3 location"><a href="#">المملكة العربية</a></li>
                        <li class="mb-3 telephon"><a href="#">+68445889955</a></li>
                        <li class="mb-3 fax"><a href="#">659847548887</a></li>
                        <li class="mb-3 mail"><a href="#">alia@bb4it.com </a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="by pt-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 text-right">
                        <p class="">جميع الحقوق محفوظه لشركة احمد تيسير ابراهيم وشريكة 2018</p>
                    </div>
                    <div class="col-md-6">
                        <p class="">تصميم وبرمجة : <span><a href="#">بريمكس</a></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</foote>

<script src="js\jquery.js"></script>
<script src="js\popper.js"></script>
<script src="js\bootstrap4.js"></script>
<script src="js\owl.carousel.min.js"></script>
<script src="js\main.js"></script>
</body>
</html>