
$(document).ready(function(){
    $('.open-menu').click(function(){
        $('.menu2').css({"width":"60%",})
        $('.side-menu-header').css({"left":"40%",})
        $(this).toggle();
        $('.side-menu-headerspan').toggle();

    });
    $('.close-menu').click(function(){
        $(this).parent().css({"width":"0",})
        $('.side-menu-header').css({"left":"0",})
        $('.open-menu').toggle();
        $('.side-menu-header span').toggle();
    });

    //main  owl-carousle
    $('.main-carousle.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        rtl:true,
        nav:true,
        dots:true,
        autoplay:true,
        autoplayTimeout:3000,
        navText:["",""],
        responsive:{
            0:{
                items:1
            }
        }
    })

    //product  owl-carousle
    $('.services.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        rtl:true,
        nav:false,
        dots:true,
        autoplay:true,
        autoplayTimeout:3000,
        responsive:{
            0:{
                items:1
            },
            500:{
                items:2
            },
            1100:{
                items:3
            }
    
        }
    });

});












