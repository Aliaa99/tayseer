<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>tayseer</title>
    <link rel="stylesheet" href="css/bootstrap4.css">
    <link rel="stylesheet" href="css/bootstrap4rtl.css">
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/hover-min.css">
    <link rel="stylesheet" href="css/stylesheet.css">
    <link rel="shortcut icon" href="images/logo.png">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
<div class="main-haeder">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-sm-2">
                <div class="logo-img">
                    <img src="images/logo.png" alt="">
                </div>
            </div>
            <div class="col-lg-6 col-lg-offset-1 col-sm-6">
                <ul class="nav list mt-5">
                    <li class="nav-item active">
                       <a class="nav-link" href="index.php">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="about-us.php">الرؤية</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="services.php">خدمات محاسبية</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="consoltation.php">الاستشارات</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="contact-us.php">تواصل معنا</a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-2 col-sm-4">
                <div class="social1">
                   <ul class="sociallist mt-5">
                       <li class="px-2 hvr-float"><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                       <li class="px-2 hvr-float"><a href="#"><i class="fab fa-instagram"></i></a></li>
                       <li class="px-2 hvr-float"><a href="#"><i class="fab fa-twitter"></i></a></li>
                       <li class="px-2 hvr-float"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                       <li class="px-2 hvr-float"><a href="#"><img src="images/en.png" alt=""></a></li>
                   </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- side menu-->
<div class="side-menu">
    <div class="container">
       <div class="side-menu-header">
          <a href="#side-list" class="open-menu">
             <i class="fas fa-align-justify"></i>
          </a>
          <a href="#" class="logo-img">
            <img src="images/logo.png">
          </a>
        </div>
        <div class="menu2 animated fadeInRight" id="side-list">
            <a href="#side-list" class="close-menu">
              <i class="fa fa-times" aria-hidden="true"></i>
            </a>
             <ul>
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">الرئيسية</a>
                </li>
                <li class="nav-item">
                       <a class="nav-link" href="about-us.php">الرؤية</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="services.php">خدمات محاسبية</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="consoltation.php">الاستشارات</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="contact-us.php">تواصل معنا</a>
                    </li>
             </ul>
             <div class="social">
                   <ul class="sociallist mt-5">
                       <li class="px-2 hvr-float"><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                       <li class="px-2 hvr-float"><a href="#"><i class="fab fa-instagram"></i></a></li>
                       <li class="px-2 hvr-float"><a href="#"><i class="fab fa-twitter"></i></a></li>
                       <li class="px-2 hvr-float"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                       <li class="px-2 hvr-float"><a href="#"><img src="images/en.png" alt=""></a></li>
                   </ul>
                </div>

        </div>

    </div>
</div>
</header>
