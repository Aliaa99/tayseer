<?php
include 'header.php';
?>

<div class="header-main py-5 text-right">
    <div class="container">
        <h2  class="mb-3">تواصل معنا</h2>
        <a href="index.php">الرئيسية</a>
    </div>
</div> 

<div class="container">
    <div class="row">
        <div class="col-md-5">
            <div class="contact-us text-right">
            <h5 class="pt-5">تواصل معنا </h5>
                <ul class="pt-3 mt-4">
                    <li class="mb-3 location"><a href="#" class="hvr-glow">المملكة العربية</a></li>
                    <li class="mb-3 telephon"><a href="#" class="hvr-glow">+68445889955</a></li>
                    <li class="mb-3 fax"><a href="#" class="hvr-glow">659847548887</a></li>
                    <li class="mb-3 mail"><a href="#" class="hvr-glow">alia@bb4it.com </a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-6">
            <div class="contact-us text-right">
              <h5 class="pt-5">ارسال رسالة </h5>
                <form action="" class="my-4 py-3">
                    <div class="form-control">
                        <input type="text" placeholder="الاسم" class="radius px-2 py-2 mb-2">
                    </div>
                    <div class="form-control">
                        <input type="email" placeholder="الإيميل" class="radius px-2 py-2 mb-2">
                    </div>
                    <div class="form-control">
                        <textarea name="" id=""  rows="8" placeholder="الرسالة" class="radius px-2 py-2 mb-2"></textarea>
                    </div>
                    <div class="form-control ">
                        <button class="background-link hvr-float-shadow"> ارسال الان </button>
                    </div>
                </form>
            </div>
        </div>        
    </div>
</div>






<?php
include 'footer.php';
?>
