<?php
include 'header.php';
?>

<?php
include 'main-carousle.php';
?>
 
<div class="my-5 who-we-are">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
              <img src="images/profile.png" alt="">
            </div>
            <div class="col-md-8 col-sm-6">
                <div class="content mr-5">
                    <h4 class="mb-4"><span class="head">من نحن</span></h4>
                    <div class="text-about">
                        <p>هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال </p>
                    </div>
                    <div class="mt-5">
                        <a href="#" class="transparent-link ml-3 hvr-float-shadow mb-3">قراءة المزيد</a>
                        <a href="services.php" class="background-link hvr-float-shadow mb-3">الخدمات</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="second-carousle py-5">
    <div class="container">
        <h4 class="mb-4"><span class="head">الخدمات المحاسبية</span></h4>
        <div class="services owl-carousel owl-theme">
            <div class="item">
                <a href="single-service.php" class="text-right">
                    <img src="images/Layer 1.svg" alt="">
                    <h5>الاستشارات الضريبية </h5>
                    <p>يقدم مكتبنا خدمات الاستشارات الضريبية لعملائنا من الشركات بداية من تجهيز مستندات الفحص الضريبي، وحضور الفحص الضريبي لتوضيح وجهة نظر  ... </p>
                </a>
            </div>
            <div class="item">
                <a href="single-service.php" class="text-right">
                    <img src="images/service2.svg" alt="">
                    <h5>الاستشارات المحاسبية  </h5>
                    <p>يقدم مكتبنا خدمات الاستشارات المحاسبية من خلال إجراء المقابلات المنتظمة مع القطاعات المالية بالشركات والتعرف على المشكلات المحاسبية والأثر المحاسبي   ...</p>
                </a>
            </div>
            <div class="item">
                <a href="single-service.php" class="text-right">
                    <img src="images/service3.svg" alt="">
                    <h5>المراجعة الداخلية  </h5>
                    <p>لمكتبنا العديد من الخبرات في مجالات المراجعة الداخلية لكافة الأنشطة والشركات بالتنسيق مع مراقب الحسابات الخارجي لضبط خطة عملية   ... </p>
                </a>
            </div>
            <div class="item">
                <a href="single-service.php" class="text-right">
                    <img src="images/service3.svg" alt="">
                    <h5>المراجعة الداخلية  </h5>
                    <p>لمكتبنا العديد من الخبرات في مجالات المراجعة الداخلية لكافة الأنشطة والشركات بالتنسيق مع مراقب الحسابات الخارجي لضبط خطة عملية   ... </p>
                </a>
            </div>

        </div>
    </div>
</div>

<div class="up-form pt-5">
  <div class="container">
        <h4 class="mb-5"><span class="head">أرسل استشارتك الان</span></h4>
        <p>محاسبون قانونيون ، مراقبى حسابات ، مراجعى حسابات ، مستشارون ماليون واداريون ، خبراء الضرائب </p>
  </div>
</div>



<?php
include 'share-form.php';
?>



<?php
include 'footer.php';
?>
