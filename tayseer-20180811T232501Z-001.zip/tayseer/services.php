<?php
include 'header.php';
?>

<div class="header-main py-5 text-right">
    <div class="container">
        <h2  class="mb-3">الخدمات المحاسبية</h2>
        <a href="index.php">الرئيسية</a>
    </div>
</div> 
 

<div class="second-carousle py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="services text-right">
                    <div class="owl-stage-outer">
                        <div class="item">
                            <a href="#" class="text-right">
                                <img src="images/Layer 1.svg" alt="">
                                <h5>الاستشارات الضريبية </h5>
                                <p>يقدم مكتبنا خدمات الاستشارات الضريبية لعملائنا من الشركات بداية من تجهيز مستندات الفحص الضريبي، وحضور الفحص الضريبي لتوضيح وجهة نظر  ... </p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="services text-right">
                    <div class="owl-stage-outer">
                        <div class="item">
                            <a href="#" class="text-right">
                                <img src="images/Layer 1.svg" alt="">
                                <h5>الاستشارات الضريبية </h5>
                                <p>يقدم مكتبنا خدمات الاستشارات الضريبية لعملائنا من الشركات بداية من تجهيز مستندات الفحص الضريبي، وحضور الفحص الضريبي لتوضيح وجهة نظر  ... </p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="services text-right">
                    <div class="owl-stage-outer">
                        <div class="item">
                            <a href="#" class="text-right">
                                <img src="images/Layer 1.svg" alt="">
                                <h5>الاستشارات الضريبية </h5>
                                <p>يقدم مكتبنا خدمات الاستشارات الضريبية لعملائنا من الشركات بداية من تجهيز مستندات الفحص الضريبي، وحضور الفحص الضريبي لتوضيح وجهة نظر  ... </p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>







<?php
include 'footer.php';
?>
